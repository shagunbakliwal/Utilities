# Spring Batch + Mockito Test Automation Demo

This project demonstrates:
- Spring Batch components: ItemReader, ItemProcessor, ItemWriter, Tasklet
- JUnit 5 + Mockito test cases
- OpenRewrite recipe to auto-generate Mockito-based test skeletons

---

## ✅ Included Components

| Component     | File                        |
|---------------|-----------------------------|
| Reader        | `SimpleItemReader.java`     |
| Processor     | `SimpleItemProcessor.java`  |
| Writer        | `SimpleItemWriter.java`     |
| Tasklet       | `SimpleTasklet.java`        |

## 🧪 Tests

| Test Class                 | Coverage                        |
|----------------------------|----------------------------------|
| SimpleItemReaderTest       | Reader unit test                |
| SimpleItemProcessorTest    | Processor transformation logic  |
| SimpleItemWriterTest       | Verifies `write()` execution    |
| SimpleTaskletTest          | Tasklet behavior with mocks     |

---

## 🔁 OpenRewrite Setup

### Recipe File
- `rewrite/generate-mockito-recipe.yml`

### Java Recipe
- `rewrite/GenerateMockitoTestSkeletonImpl.java`

---

## ⚙️ Maven Plugin Setup

Make sure to run the following command to apply the recipe:

```bash
mvn rewrite:run -DactiveRecipes=com.example.GenerateMockitoTestSkeleton
```

---

## 🧰 Maven Dependencies

See `pom.xml` for:

- Spring Batch
- Spring Boot
- Spring Batch Test
- JUnit 5
- Mockito
- OpenRewrite core + Maven plugin

---

## 📂 Directory Structure

```
src/
├── main/java/com/example/batch/
├── test/java/com/example/batch/
rewrite/
    ├── generate-mockito-recipe.yml
    └── GenerateMockitoTestSkeletonImpl.java
```