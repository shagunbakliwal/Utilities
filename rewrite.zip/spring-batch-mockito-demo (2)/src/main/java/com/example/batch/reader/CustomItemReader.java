package com.example.batch.reader;

import org.springframework.batch.item.ItemReader;
import org.springframework.stereotype.Component;

@Component
public class CustomItemReader implements ItemReader<String> {
    private int count = 0;

    @Override
    public String read() throws Exception {
        if (count < 5) {
            return "Item " + count++;
        }
        return null;
    }
}