package com.example.rewrite;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Value;
import org.jspecify.annotations.NonNull;
import org.openrewrite.*;
import org.openrewrite.java.*;
import org.openrewrite.java.tree.J;
import org.openrewrite.java.tree.JavaType;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;

@Value
@EqualsAndHashCode(callSuper = false)
public class GenerateBatchTestsRecipe extends Recipe {
    @Option(displayName = "Test Package Name",
            description = "The package name for generated test classes.",
            example = "com.example.batch")
    @NonNull
    String testPackageName;

    @JsonCreator
    public GenerateBatchTestsRecipe(@NonNull @JsonProperty("testPackageName") String testPackageName) {
        this.testPackageName = testPackageName;
    }

    @Override
    public String getDisplayName() {
        return "Generate JUnit 5 and Mockito Tests for Spring Batch";
    }

    @Override
    public String getDescription() {
        return "Generates JUnit 5 test classes with Mockito for Spring Batch components.";
    }

    @Override
    public TreeVisitor<?, ExecutionContext> getVisitor() {
        return new JavaIsoVisitor<ExecutionContext>() {
            @Override
            public J.ClassDeclaration visitClassDeclaration(J.ClassDeclaration classDecl, ExecutionContext ctx) {
                classDecl = super.visitClassDeclaration(classDecl, ctx);

                // Check if the class is a Spring Batch component
                boolean isBatchComponent = isBatchComponent(classDecl);
                if (!isBatchComponent) {
                    return classDecl;
                }

                String className = classDecl.getSimpleName();
                String packageName = classDecl.getType() != null && classDecl.getType() instanceof JavaType.FullyQualified
                        ? ((JavaType.FullyQualified) classDecl.getType()).getFullyQualifiedName()
                        : "com.example.batch";
                String testClassName = className + "Test";
                String testPackage = testPackageName + packageName.substring(packageName.lastIndexOf("com.example.batch") + "com.example.batch".length());

                // Generate test class content
                String testClassContent = generateTestClassContent(className, testPackage, classDecl);

                // Create a new test file
                JavaTemplate testTemplate = JavaTemplate.builder(testClassContent)
                        .imports(
                                "org.junit.jupiter.api.Test",
                                "org.junit.jupiter.api.extension.ExtendWith",
                                "org.mockito.InjectMocks",
                                "org.mockito.Mock",
                                "org.mockito.junit.jupiter.MockitoExtension",
                                "org.springframework.batch.core.StepExecution",
                                "org.springframework.batch.test.StepScopeTestExecutionListener",
                                "org.springframework.test.context.junit.jupiter.SpringExtension"
                        )
                        .build();

                // Add the test file to the source files
                String testFilePath = "src/test/java/" + testPackage.replace(".", "/") + "/" + testClassName + ".java";
                SourceFile testSourceFile = testTemplate.apply(new Cursor(getCursor(), classDecl), classDecl.getCoordinates().replace());
                //getCursor().getRoot().getResult().addChange(new AddFile(testFilePath, testSourceFile));


                return classDecl;
            }

            private boolean isBatchComponent(J.ClassDeclaration classDecl) {
                JavaType type = classDecl.getType();
                if (type == null || !(type instanceof JavaType.FullyQualified)) {
                    return false;
                }
                JavaType.FullyQualified fqType = (JavaType.FullyQualified) type;

                // Check for Spring Batch interfaces
                boolean implementsBatchInterface = fqType.getInterfaces().stream()
                        .filter(iface -> iface instanceof JavaType.FullyQualified)
                        .map(iface -> ((JavaType.FullyQualified) iface).getFullyQualifiedName())
                        .anyMatch(fqn -> fqn.equals(ItemReader.class.getName()) ||
                                fqn.equals(ItemProcessor.class.getName()) ||
                                fqn.equals(ItemWriter.class.getName()));

                // Check for @EnableBatchProcessing annotation
                boolean hasBatchAnnotation = classDecl.getLeadingAnnotations().stream()
                        .map(annotation -> annotation.getType())
                        .filter(annType -> annType instanceof JavaType.FullyQualified)
                        .map(annType -> ((JavaType.FullyQualified) annType).getFullyQualifiedName())
                        .anyMatch(fqn -> fqn.equals(EnableBatchProcessing.class.getName()));

                return implementsBatchInterface || hasBatchAnnotation;
            }

            private String generateTestClassContent(String className, String testPackage, J.ClassDeclaration classDecl) {
                StringBuilder testContent = new StringBuilder();
                testContent.append("package ").append(testPackage).append(";\n\n");
                testContent.append("import org.junit.jupiter.api.Test;\n");
                testContent.append("import org.junit.jupiter.api.extension.ExtendWith;\n");
                testContent.append("import org.mockito.InjectMocks;\n");
                testContent.append("import org.mockito.Mock;\n");
                testContent.append("import org.mockito.junit.jupiter.MockitoExtension;\n");
                testContent.append("import org.springframework.batch.core.StepExecution;\n");
                testContent.append("import org.springframework.batch.test.StepScopeTestExecutionListener;\n");
                testContent.append("import org.springframework.test.context.junit.jupiter.SpringExtension;\n");
                testContent.append("import static org.junit.jupiter.api.Assertions.*;\n");
                testContent.append("import static org.mockito.Mockito.*;\n\n");

                testContent.append("@ExtendWith(MockitoExtension.class)\n");
                testContent.append("@ExtendWith(SpringExtension.class)\n");
                testContent.append("public class ").append(className).append("Test {\n\n");

                // Add fields for mocks and class under test
                testContent.append("    @InjectMocks\n");
                testContent.append("    private ").append(className).append(" ").append(toCamelCase(className)).append(";\n\n");

                // Add mock fields and test methods based on class type
                if (isItemReader(classDecl)) {
                    testContent.append("    @Mock\n");
                    testContent.append("    private StepExecution stepExecution;\n\n");
                    testContent.append("    @Test\n");
                    testContent.append("    void testRead() throws Exception {\n");
                    testContent.append("        // Arrange\n");
                    testContent.append("        // TODO: Configure mocks\n\n");
                    testContent.append("        // Act\n");
                    testContent.append("        Object result = ").append(toCamelCase(className)).append(".read();\n\n");
                    testContent.append("        // Assert\n");
                    testContent.append("        assertNotNull(result);\n");
                    testContent.append("    }\n");
                } else if (isItemProcessor(classDecl)) {
                    testContent.append("    @Mock\n");
                    testContent.append("    private StepExecution stepExecution;\n\n");
                    testContent.append("    @Test\n");
                    testContent.append("    void testProcess() throws Exception {\n");
                    testContent.append("        // Arrange\n");
                    testContent.append("        Object input = new Object();\n");
                    testContent.append("        // TODO: Configure mocks\n\n");
                    testContent.append("        // Act\n");
                    testContent.append("        Object result = ").append(toCamelCase(className)).append(".process(input);\n\n");
                    testContent.append("        // Assert\n");
                    testContent.append("        assertNotNull(result);\n");
                    testContent.append("    }\n");
                } else if (isItemWriter(classDecl)) {
                    testContent.append("    @Mock\n");
                    testContent.append("    private StepExecution stepExecution;\n\n");
                    testContent.append("    @Test\n");
                    testContent.append("    void testWrite() throws Exception {\n");
                    testContent.append("        // Arrange\n");
                    testContent.append("        java.util.List<Object> items = java.util.Collections.singletonList(new Object());\n");
                    testContent.append("        // TODO: Configure mocks\n\n");
                    testContent.append("        // Act\n");
                    testContent.append("        ").append(toCamelCase(className)).append(".write(items);\n\n");
                    testContent.append("        // Assert\n");
                    testContent.append("        verify(stepExecution, times(1)).setWriteCount(1);\n");
                    testContent.append("    }\n");
                } else if (isBatchConfiguration(classDecl)) {
                    testContent.append("    @Mock\n");
                    testContent.append("    private JobBuilderFactory jobBuilderFactory;\n");
                    testContent.append("    @Mock\n");
                    testContent.append("    private StepBuilderFactory stepBuilderFactory;\n\n");
                    testContent.append("    @Test\n");
                    testContent.append("    void testJobConfiguration() {\n");
                    testContent.append("        // Arrange\n");
                    testContent.append("        // TODO: Configure mocks\n\n");
                    testContent.append("        // Act\n");
                    testContent.append("        // TODO: Call job or step configuration method\n\n");
                    testContent.append("        // Assert\n");
                    testContent.append("        assertTrue(true); // Placeholder assertion\n");
                    testContent.append("    }\n");
                }

                testContent.append("}\n");
                return testContent.toString();
            }

            private boolean isItemReader(J.ClassDeclaration classDecl) {
                JavaType type = classDecl.getType();
                return type instanceof JavaType.FullyQualified &&
                        ((JavaType.FullyQualified) type).getInterfaces().stream()
                                .filter(iface -> iface instanceof JavaType.FullyQualified)
                                .map(iface -> ((JavaType.FullyQualified) iface).getFullyQualifiedName())
                                .anyMatch(fqn -> fqn.equals(ItemReader.class.getName()));
            }

            private boolean isItemProcessor(J.ClassDeclaration classDecl) {
                JavaType type = classDecl.getType();
                return type instanceof JavaType.FullyQualified &&
                        ((JavaType.FullyQualified) type).getInterfaces().stream()
                                .filter(iface -> iface instanceof JavaType.FullyQualified)
                                .map(iface -> ((JavaType.FullyQualified) iface).getFullyQualifiedName())
                                .anyMatch(fqn -> fqn.equals(ItemProcessor.class.getName()));
            }

            private boolean isItemWriter(J.ClassDeclaration classDecl) {
                JavaType type = classDecl.getType();
                return type instanceof JavaType.FullyQualified &&
                        ((JavaType.FullyQualified) type).getInterfaces().stream()
                                .filter(iface -> iface instanceof JavaType.FullyQualified)
                                .map(iface -> ((JavaType.FullyQualified) iface).getFullyQualifiedName())
                                .anyMatch(fqn -> fqn.equals(ItemWriter.class.getName()));
            }

            private boolean isBatchConfiguration(J.ClassDeclaration classDecl) {
                return classDecl.getLeadingAnnotations().stream()
                        .map(annotation -> annotation.getType())
                        .filter(annType -> annType instanceof JavaType.FullyQualified)
                        .map(annType -> ((JavaType.FullyQualified) annType).getFullyQualifiedName())
                        .anyMatch(fqn -> fqn.equals(EnableBatchProcessing.class.getName()));
            }

            private String toCamelCase(String className) {
                return Character.toLowerCase(className.charAt(0)) + className.substring(1);
            }
        };
    }
}